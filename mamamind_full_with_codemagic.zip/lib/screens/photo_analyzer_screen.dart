import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ai/vision_service.dart';

class PhotoAnalyzerScreen extends StatefulWidget {
  static const route = '/photo';
  const PhotoAnalyzerScreen({super.key});

  @override
  State<PhotoAnalyzerScreen> createState() => _PhotoAnalyzerScreenState();
}

class _PhotoAnalyzerScreenState extends State<PhotoAnalyzerScreen> {
  File? _image;
  VisionResult? _result;
  bool _busy = false;
  final _picker = ImagePicker();
  final _vision = VisionService();

  Future<void> _pick(ImageSource src) async {
    try {
      final x = await _picker.pickImage(source: src, imageQuality: 85);
      if (x == null) return;
      setState(() {
        _image = File(x.path);
        _result = null;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Не удалось получить фото: $e')),
      );
    }
  }

  Future<void> _analyze() async {
    final img = _image;
    if (img == null || _busy) return;
    setState(() => _busy = true);
    try {
      final r = await _vision.analyzePhoto(img);
      setState(() {
        _result = r;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка анализа: $e')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Фото-анализ')), 
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              ElevatedButton.icon(
                onPressed: _busy ? null : () => _pick(ImageSource.camera),
                icon: const Icon(Icons.photo_camera_outlined),
                label: const Text('Камера'),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: _busy ? null : () => _pick(ImageSource.gallery),
                icon: const Icon(Icons.photo_library_outlined),
                label: const Text('Галерея'),
              ),
              const Spacer(),
              FilledButton.icon(
                onPressed: _busy ? null : _analyze,
                icon: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome_outlined),
                label: Text(_busy ? 'Анализ...' : 'Анализ'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          if (_image != null)
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.file(_image!),
            ),
          const SizedBox(height: 16),
          if (_result != null)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Результат: ${_result!.label}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text(_result!.summary),
                    const SizedBox(height: 8),
                    Row(children: [
                      const Text('Уровень: '),
                      Chip(label: Text(_result!.severity == 0 ? 'ОК' : _result!.severity == 1 ? 'Внимание' : 'Тревога')),
                    ]),
                    const SizedBox(height: 8),
                    const Text('Дисклеймер: советы носят справочный характер и не заменяют врача.'),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
