import 'package:flutter/material.dart';
import 'journal_screen.dart';
import 'chat_screen.dart';
import 'photo_analyzer_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  final _tabs = const [
    JournalScreen(),
    ChatScreen(),
    PhotoAnalyzerScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _tabs[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Дневник'),
          NavigationDestination(icon: Icon(Icons.smart_toy_outlined), label: 'ИИ-чат'),
          NavigationDestination(icon: Icon(Icons.photo_camera_outlined), label: 'Фото'),
          NavigationDestination(icon: Icon(Icons.child_care_outlined), label: 'Профиль'),
        ],
        onDestinationSelected: (i) => setState(() => _index = i),
      ),
    );
  }
}
