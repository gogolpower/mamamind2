import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../repositories/event_repository.dart';
import '../models/event.dart';
import '../widgets/event_card.dart';

class JournalScreen extends StatefulWidget {
  static const route = '/journal';
  const JournalScreen({super.key});

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<EventRepository>().refresh();
    });
  }

  void _addQuick(EventType type) async {
    final repo = context.read<EventRepository>();
    final e = BabyEvent(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      type: type,
      timestamp: DateTime.now(),
      note: null,
    );
    await repo.addEvent(e);
  }

  @override
  Widget build(BuildContext context) {
    final events = context.watch<EventRepository>().events;

    return Scaffold(
      appBar: AppBar(title: const Text('Дневник малыша')),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: events.length,
        itemBuilder: (_, i) => EventCard(event: events[i]),
      ),
      floatingActionButton: ExpandableFab(onAdd: _addQuick),
    );
  }
}

class ExpandableFab extends StatefulWidget {
  final void Function(EventType) onAdd;
  const ExpandableFab({super.key, required this.onAdd});

  @override
  State<ExpandableFab> createState() => _ExpandableFabState();
}

class _ExpandableFabState extends State<ExpandableFab> with SingleTickerProviderStateMixin {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_open)
          Wrap(
            spacing: 8,
            direction: Axis.vertical,
            children: [
              _miniBtn(Icons.local_drink, 'Кормление', () => widget.onAdd(EventType.feed)),
              _miniBtn(Icons.baby_changing_station, 'Подгузник', () => widget.onAdd(EventType.diaper)),
              _miniBtn(Icons.bedtime, 'Сон (нач.)', () => widget.onAdd(EventType.sleepStart)),
              _miniBtn(Icons.bedtime_off, 'Сон (кон.)', () => widget.onAdd(EventType.sleepEnd)),
              _miniBtn(Icons.campaign, 'Плач', () => widget.onAdd(EventType.cry)),
              _miniBtn(Icons.note_add, 'Заметка', () => widget.onAdd(EventType.note)),
            ],
          ),
        const SizedBox(height: 8),
        FloatingActionButton(
          onPressed: () => setState(() => _open = !_open),
          child: Icon(_open ? Icons.close : Icons.add),
        ),
      ],
    );
  }

  Widget _miniBtn(IconData icon, String label, VoidCallback onTap) {
    return ElevatedButton.icon(
      onPressed: () {
        setState(() => _open = false);
        onTap();
      },
      icon: Icon(icon, size: 18),
      label: Text(label),
    );
  }
}
