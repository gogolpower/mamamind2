import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  static const route = '/profile';
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Профиль малыша')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          ListTile(
            leading: Icon(Icons.child_care_outlined),
            title: Text('Имя: Малыш (демо)'),
            subtitle: Text('Дата рождения: 2025-08-22'),
          ),
          Divider(),
          ListTile(
            leading: Icon(Icons.vaccines_outlined),
            title: Text('Вакцинации'),
            subtitle: Text('Добавьте записи в будущих версиях'),
          ),
          ListTile(
            leading: Icon(Icons.folder_shared_outlined),
            title: Text('Медицинские документы'),
            subtitle: Text('Фото/сканы анализов и визитов'),
          ),
          Padding(
            padding: EdgeInsets.only(top: 12),
            child: Text('Данные конфиденциальны. Включите PIN/FaceID в настройках (в следующих версиях).'),
          ),
        ],
      ),
    );
  }
}
