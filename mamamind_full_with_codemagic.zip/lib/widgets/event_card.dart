import 'package:flutter/material.dart';
import '../models/event.dart';

class EventCard extends StatelessWidget {
  final BabyEvent event;
  const EventCard({super.key, required this.event});

  @override
  Widget build(BuildContext context) {
    final icon = switch (event.type) {
      EventType.feed => Icons.local_drink,
      EventType.diaper => Icons.baby_changing_station,
      EventType.sleepStart => Icons.bedtime,
      EventType.sleepEnd => Icons.bedtime_off,
      EventType.cry => Icons.campaign,
      EventType.note => Icons.note,
    };

    final title = switch (event.type) {
      EventType.feed => 'Кормление',
      EventType.diaper => 'Подгузник',
      EventType.sleepStart => 'Сон — начало',
      EventType.sleepEnd => 'Сон — конец',
      EventType.cry => 'Плач',
      EventType.note => 'Заметка',
    };

    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(event.note ?? event.timestamp.toLocal().toString()),
        trailing: _trailing(),
      ),
    );
  }

  Widget? _trailing() {
    if (event.type == EventType.cry && event.crySubtype != null) {
      final label = switch (event.crySubtype!) {
        CrySubtype.hunger => 'Голод',
        CrySubtype.pain => 'Боль',
        CrySubtype.discomfort => 'Дискомфорт',
        CrySubtype.tired => 'Усталость',
        CrySubtype.unknown => 'Неизвестно',
      };
      final conf = (event.cryConfidence ?? 0) * 100;
      return Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(label),
          Text('${conf.toStringAsFixed(0)}%'),
        ],
      );
    }
    return null;
  }
}
