class Baby {
  final String id;
  final String name;
  final DateTime birthDate;

  Baby({required this.id, required this.name, required this.birthDate});
}
