enum EventType { feed, diaper, sleepStart, sleepEnd, cry, note }

enum CrySubtype { hunger, pain, discomfort, tired, unknown }

enum DiaperSubtype { pee, poop, mixed }

class BabyEvent {
  final String id;
  final EventType type;
  final DateTime timestamp;
  final String? note;

  // Доп. поля для разных типов событий
  final CrySubtype? crySubtype;
  final double? cryConfidence;
  final DiaperSubtype? diaperSubtype;

  BabyEvent({
    required this.id,
    required this.type,
    required this.timestamp,
    this.note,
    this.crySubtype,
    this.cryConfidence,
    this.diaperSubtype,
  });
}
