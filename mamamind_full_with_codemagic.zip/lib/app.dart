import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/journal_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/photo_analyzer_screen.dart';
import 'screens/profile_screen.dart';

class MamaMindApp extends StatelessWidget {
  const MamaMindApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MamaMind',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6C63FF)),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (_) => const HomeScreen(),
        JournalScreen.route: (_) => const JournalScreen(),
        ChatScreen.route: (_) => const ChatScreen(),
        PhotoAnalyzerScreen.route: (_) => const PhotoAnalyzerScreen(),
        ProfileScreen.route: (_) => const ProfileScreen(),
      },
    );
  }
}
