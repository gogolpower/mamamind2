import 'dart:io';

class VisionResult {
  final String label; // e.g. "poop_color_green"
  final String summary; // human-friendly
  final int severity; // 0-ok, 1-watch, 2-alert

  VisionResult({required this.label, required this.summary, required this.severity});
}

class VisionService {
  // TODO: Подключить реальный CV API / on-device TFLite.
  Future<VisionResult> analyzePhoto(File image) async {
    // Демо-логика: по размеру файла «угадываем» результат
    final length = await image.length();
    if (length % 3 == 0) {
      return VisionResult(
        label: 'poop_color_yellow',
        summary: 'Жёлтый стул — обычно норма у малышей на ГВ.',
        severity: 0,
      );
    } else if (length % 3 == 1) {
      return VisionResult(
        label: 'poop_color_green',
        summary: 'Зелёный оттенок — может быть нормой, но понаблюдайте 1–2 дня.',
        severity: 1,
      );
    } else {
      return VisionResult(
        label: 'poop_color_red_flag',
        summary: 'Красноватые вкрапления — возможно кровь. Рекомендуется консультация педиатра.',
        severity: 2,
      );
    }
  }
}
