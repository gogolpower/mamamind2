import 'dart:io';
import '../../models/event.dart';

class CryAnalyzerService {
  // TODO: Подключить on-device TFLite модель или облачный аудио-классификатор.
  Future<(CrySubtype, double)> analyzeCry(File audio) async {
    final bytes = await audio.readAsBytes();
    final score = (bytes.isNotEmpty ? bytes.first / 255.0 : 0.5);
    if (score < 0.25) return (CrySubtype.tired, 0.72);
    if (score < 0.50) return (CrySubtype.hunger, 0.78);
    if (score < 0.75) return (CrySubtype.discomfort, 0.69);
    return (CrySubtype.pain, 0.61);
  }
}
