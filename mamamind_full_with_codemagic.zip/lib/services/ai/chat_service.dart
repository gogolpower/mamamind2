import 'dart:async';

class ChatService {
  // TODO: Подключить реальный LLM API (OpenAI/Gemini/Claude).
  // Сейчас — заглушка, которая «думает» и возвращает шаблонный ответ.

  Future<String> ask(String question, {Map<String, dynamic>? context}) async {
    await Future.delayed(const Duration(milliseconds: 600));
    final age = context?['babyAgeMonths'];
    return 'Совет (демо):\n— Я учёл возраст малыша: \${age ?? 'n/a'} мес.\n— По вашему вопросу «$question»:\nПопробуйте оценить последние события (сон/кормление/подгузник). Если плач резкий и высокий — проверьте дискомфорт или боль. Если нарастает — возможно голод.';
  }
}
