import '../../models/event.dart';

abstract class StorageService {
  Future<void> saveEvent(BabyEvent event);
  Future<List<BabyEvent>> listEvents();
  Future<void> removeEvent(String id);
}
