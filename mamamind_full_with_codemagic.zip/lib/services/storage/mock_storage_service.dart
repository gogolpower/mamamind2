import 'dart:async';
import 'package:collection/collection.dart';
import '../../models/event.dart';
import 'storage_service.dart';

class MockStorageService implements StorageService {
  final List<BabyEvent> _events = [];

  @override
  Future<void> saveEvent(BabyEvent event) async {
    _events.removeWhere((e) => e.id == event.id);
    _events.add(event);
  }

  @override
  Future<List<BabyEvent>> listEvents() async {
    final sorted = _events.sortedBy((e) => e.timestamp).reversed.toList();
    return List<BabyEvent>.unmodifiable(sorted);
  }

  @override
  Future<void> removeEvent(String id) async {
    _events.removeWhere((e) => e.id == id);
  }
}
