import 'package:flutter/foundation.dart';
import '../models/event.dart';
import '../services/storage/mock_storage_service.dart';
import '../services/storage/storage_service.dart';

class EventRepository extends ChangeNotifier {
  final StorageService _storage = MockStorageService(); // TODO: заменить на реальное хранилище
  List<BabyEvent> _events = [];

  List<BabyEvent> get events => _events;

  Future<void> refresh() async {
    _events = await _storage.listEvents();
    notifyListeners();
  }

  Future<void> addEvent(BabyEvent e) async {
    await _storage.saveEvent(e);
    await refresh();
  }

  Future<void> removeEvent(String id) async {
    await _storage.removeEvent(id);
    await refresh();
  }
}
